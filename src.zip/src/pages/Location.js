import React, { useState, useLayoutEffect, useEffect } from "react";
import { View, FlatList, Button, Text, StyleSheet, TextInput, TouchableOpacity, Image, Keyboard, Dimensions, Modal,  KeyboardAvoidingView } from "react-native";

import MapView, { Marker, PROVIDER_GOOGLE } from "react-native-maps";
import Geolocation from '@react-native-community/geolocation';
import AsyncStorage from "@react-native-community/async-storage";
import { useFocusEffect } from '@react-navigation/native';
import { TouchableHighlight } from "react-native-gesture-handler";
import CheckBox from 'react-native-check-box';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
 } from 'react-native-responsive-screen'

const App = ({ navigation, route }) => {

  const [metaDatas, setMetaDatas] = useState([])
  const [tagID, setTagID] = useState('')
  const [tagType, setTagType] = useState('')
  const [searchContent, setSearchContent] = useState('')
  const [tempMetaData, setTempMetaData] = useState()
  const [btnColor, setBtnColor] = useState('white')
  const [mapTypes, setMapTypes] = useState('standard')
  const [nfcTAG, setNfcTAG] = useState('')
  const [energyArt, setEnergyArt] = useState('')
  const [flag, setFlag] = useState(true)
  const [userAutherity, setUserAutherity] = useState()
  const [currentLatitude, setCurrentLatitude] = useState(37.33233141)
  const [currentLogitude, setCurrentLongitude] = useState(-122.0312186)
  const [userTechnicalCatetory, setUserTechnicalCategory] = useState([])
  const [modalVisible, setModalVisible] = useState(false)
  const [filterStatus, setFilterStatus] = useState(false)

  const { height, width } = Dimensions.get('window');
  const LATITUDE_DELTA = 0.009
  const LONGITUDE_DELTA = LATITUDE_DELTA * (width / height)
  const colorButton = {
    Water: require('../assets/images/metaIcon/blue.png'),
    Electricity: require('../assets/images/metaIcon/green.png'),
    CO2: require('../assets/images/metaIcon/darkgrey.png'),
    NH3: require('../assets/images/metaIcon/black.png'),
    "Compressed Air": require('../assets/images/metaIcon/orange.png'),
    Heat: require('../assets/images/metaIcon/red.png'),
    Glycol: require('../assets/images/metaIcon/white.png'),
    "Waste Water": require('../assets/images/metaIcon/brown.png'),
    pH: require('../assets/images/metaIcon/purple.png'),
    Acid: require('../assets/images/metaIcon/yellow.png'),
  };

  const metaDataType = [
    { item: 'Electricity', text: 'Electricity', value: 'Electricity' },
    { item: 'Water', text: 'Water', value: 'Water' },
    { item: 'CO2', text: 'CO2', value: 'CO2' },
    { item: 'NH3', text: 'NH3', value: 'NH3' },
    { item: 'Compressed Air', text: 'Compressed Air', value: 'Compressed Air' },
    { item: 'Heat', text: 'Heat', value: 'Heat' },
    { item: 'Glycol', text: 'Glycol', value: 'Glycol' },
    { item: 'Waste Water', text: 'Waste Water', value: 'Waste Water' },
    { item: 'pH', text: 'pH', value: 'pH' },
    { item: 'Acid', text: 'Acid', value: 'Acid' },
  ]

  const [stateCheckBox, setStateCheckBox] = useState({
    Water: false,
    Electricity: false,
    CO2: false,
    NH3: false,
    "Compressed Air": false,
    Heat: false,
    Glycol: false,
    "Waste Water": false,
    pH: false,
    Acid: false,
  })

  const [initialRegion, setInitialRegion] = useState({
    latitude: 55.578277,
    longitude: 9.619496, 
    latitudeDelta: LATITUDE_DELTA, 
    longitudeDelta: LONGITUDE_DELTA, 
  })

  useFocusEffect(() => {
    if(flag) {
      getMetaDatas()
      setFlag(false)
      AsyncStorage.getItem('customerID').then(value => {
        setUserAutherity(value)
      });
    }
    setTagType('')
  });

  useEffect(() => {
    if (route.params) {
        const { equipment_name } = route.params;
        console.log(initialRegion)
        setSearchContent(equipment_name);
        _handleSearchContent(equipment_name);

    } 
  }, [route.params])

  getMetaDatas = () => {
    AsyncStorage.getItem('customerID').then(value => {
      let api_url = 'http://23e64e346a8d.ngrok.io/getUserByID/' + value;
      return fetch(api_url)
        .then((response) => response.json())
        .then((responseJson) => {
          let convertJson = JSON.parse(responseJson.technical_authority);
          api_url = 'http://23e64e346a8d.ngrok.io/getMetaMainDatas/';
          return fetch(api_url)
            .then((response) => response.json())
            .then((responseJson) => {
              var filterdData = []
              convertJson.map((item) => {
                filterdData = filterdData.concat(responseJson.filter(x => x.technical_category == item.label))
              })
              setTempMetaData(filterdData)
              var userTechnicalCatetoryList = []
              convertJson.map((item) => {
                userTechnicalCatetoryList.push({item: item.label, text: item.label, value: item.label})
              })
              setUserTechnicalCategory(userTechnicalCatetoryList)
          })
        })
        .catch((error) => {
          console.error(error);
        })    
    });
  }

  _handleSearch = () => {
    if (searchContent == '') {
      return
    }
    setMetaDatas(tempMetaData)
    let searchData = (metaDatas => metaDatas.filter(x => (x.technical_category) && (x.technical_category).toLowerCase() == searchContent.toLowerCase() || (x.equipment_name) && (x.equipment_name).toLowerCase() == searchContent.toLowerCase()
      || (x.nfc_tag) && (x.nfc_tag).toLowerCase() == searchContent.toLowerCase() || (x.service_interval) && (x.service_interval).toLowerCase() == searchContent.toLowerCase() || (x.legit) && (x.legit).toLowerCase() == searchContent.toLowerCase()
      || (x.latest_service) && (x.latest_service).toLowerCase() == searchContent.toLowerCase() || (x.longitude) && (x.longitude).toLowerCase() == searchContent.toLowerCase() || (x.latitude) && (x.latitude).toLowerCase() == searchContent.toLowerCase()
      || (x.expected_service) && (x.expected_service).toLowerCase() == searchContent.toLowerCase() || (x.reminder_month) && (x.reminder_month).toLowerCase() == searchContent.toLowerCase() || (x.nfc_tag) && (x.nfc_tag).toLowerCase() == searchContent.toLowerCase()
      || (x.reminder_week) && (x.reminder_week).toLowerCase() == searchContent.toLowerCase() || (x.reminder_flag) && (x.reminder_flag).toLowerCase() == searchContent.toLowerCase()))
    setMetaDatas(searchData)
    if ((metaDatas).length > 0) {
      setRegion({
        latitude: parseFloat(metaDatas[0]["latitude"]),
        longitude: parseFloat(metaDatas[0]["longitude"]),
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
      })
    }
  }

  const [region, setRegion] = useState(initialRegion);

  _handleMarker = (metaData) => {
    setTagID(metaData["equipment_name"])
    setTagType(metaData["media_type"])
    setNfcTAG(metaData["id"])
    setEnergyArt(metaData["technical_category"])

  }

  _handleSearchContent = (searchContent) => {
    setSearchContent(searchContent)
    setMetaDatas(tempMetaData)

    if (searchContent == '') {
      setMetaDatas(tempMetaData)
      return
    }
    _handleRealtimeSearch(searchContent)
  }

  _handleRealtimeSearch = (searchContent) => {
    let tmd = tempMetaData
    let filteredValue = tmd.filter(x => (x.technical_category) && (x.technical_category).includes(searchContent) || (x.equipment_name) && ((x.equipment_name).toLowerCase()).includes(searchContent.toLowerCase())
      || (x.nfc_tag) && ((x.nfc_tag).toLowerCase()).includes(searchContent.toLowerCase()) || (x.service_interval) && ((x.service_interval).toLowerCase()).includes(searchContent.toLowerCase()) || (x.legit) && ((x.legit).toLowerCase()).includes(searchContent.toLowerCase())
      || (x.latest_service) && ((x.latest_service).toLowerCase()).includes(searchContent.toLowerCase()) || (x.longitude) && ((x.longitude).toLowerCase()).includes(searchContent.toLowerCase()) || (x.latitude) && ((x.latitude).toLowerCase()).includes(searchContent.toLowerCase())
      || (x.expected_service) && ((x.expected_service).toLowerCase()).includes(searchContent.toLowerCase()) || (x.reminder_month) && ((x.reminder_month).toLowerCase()).includes(searchContent.toLowerCase()) || (x.nfc_tag) && ((x.nfc_tag).toLowerCase()).includes(searchContent.toLowerCase())
      || (x.reminder_week) && ((x.reminder_week).toLowerCase()).includes(searchContent.toLowerCase()) || (x.reminder_flag) && ((x.reminder_flag).toLowerCase()).includes(searchContent.toLowerCase()))
    setMetaDatas(filteredValue)
  }


  useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () => (
        <View>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Text style={styles.backButton}
              source={require('../assets/images/logo.png')}>Back</Text>
          </TouchableOpacity>
        </View>
      ),
    });
  }, [navigation]);

  _goMetaData = () => {
    if (nfcTAG == '') {
      alert("Select Tag!")
      return
    }
    navigation.navigate('Metadata', { nfc_id: nfcTAG })
  }

  _goTags = () => {
    navigation.navigate('Tags')
  }

  _handleMapType = () => {
    if (mapTypes == 'standard') {
      setMapTypes('satellite')
    } else {
      setMapTypes('standard')
    }
  }

  _goActivityLog = () => {
    if (nfcTAG == '') {
      alert("Select Tag!")
      return
    }
    navigation.navigate('ActivityLog', { nfc_id: nfcTAG, equipment_name: tagID })
  }

  onRegionChange = () => {
    setInitialRegion({
      latitude: 58.586940,
      longitude: 9.726038,
      latitudeDelta: LATITUDE_DELTA,
      longitudeDelta: LONGITUDE_DELTA,
    })
  }

  _handleFilter = () => {
    var resultCheckBoxItems = []
    setFilterStatus(false)
    for (const checkBoxItem in stateCheckBox) {
      let tmd = tempMetaData
      let filteredValue = tmd.filter(x => (stateCheckBox[checkBoxItem]) && (x.technical_category).includes(checkBoxItem))
      resultCheckBoxItems = resultCheckBoxItems.concat(filteredValue)
      if (stateCheckBox[checkBoxItem]) {
        setFilterStatus(true)
      }
    }
    setMetaDatas(resultCheckBoxItems)
    setModalVisible(false)
    setEnergyArt("")
    setTagID("")
  }

  renderItem = ({ item }) => (
    <View style={styles.itemModal} >
      <View style={styles.marginLeft}>
        <TouchableHighlight onPress={() => setStateCheckBox({ ...stateCheckBox, [item.value]: !stateCheckBox[item.value] })}>
         <View style={styles.itemTitleModal} >
          <CheckBox
              onClick={(event) => {
                setStateCheckBox({ ...stateCheckBox, [item.value]: !stateCheckBox[item.value] })
              }}
              isChecked={stateCheckBox[item.value]}
          />
        </View>
        </TouchableHighlight>
      </View>
      <View style={styles.itemContentModal}>
        <Text style={styles.text}>&middot; {item.value} </Text>
      </View>
    </View>
  )

  mapStyle = [{ "elementType": "geometry", "stylers": [{ "color": "#242f3e" }] }, { "elementType": "labels.text.fill", "stylers": [{ "color": "#746855" }] }, { "elementType": "labels.text.stroke", "stylers": [{ "color": "#242f3e" }] }, { "featureType": "administrative.locality", "elementType": "labels.text.fill", "stylers": [{ "color": "#d59563" }] }, { "featureType": "poi", "elementType": "labels.text.fill", "stylers": [{ "color": "#d59563" }] }, { "featureType": "poi.park", "elementType": "geometry", "stylers": [{ "color": "#263c3f" }] }, { "featureType": "poi.park", "elementType": "labels.text.fill", "stylers": [{ "color": "#6b9a76" }] }, { "featureType": "road", "elementType": "geometry", "stylers": [{ "color": "#38414e" }] }, { "featureType": "road", "elementType": "geometry.stroke", "stylers": [{ "color": "#212a37" }] }, { "featureType": "road", "elementType": "labels.text.fill", "stylers": [{ "color": "#9ca5b3" }] }, { "featureType": "road.highway", "elementType": "geometry", "stylers": [{ "color": "#746855" }] }, { "featureType": "road.highway", "elementType": "geometry.stroke", "stylers": [{ "color": "#1f2835" }] }, { "featureType": "road.highway", "elementType": "labels.text.fill", "stylers": [{ "color": "#f3d19c" }] }, { "featureType": "transit", "elementType": "geometry", "stylers": [{ "color": "#2f3948" }] }, { "featureType": "transit.station", "elementType": "labels.text.fill", "stylers": [{ "color": "#d59563" }] }, { "featureType": "water", "elementType": "geometry", "stylers": [{ "color": "#17263c" }] }, { "featureType": "water", "elementType": "labels.text.fill", "stylers": [{ "color": "#515c6d" }] }, { "featureType": "water", "elementType": "labels.text.stroke", "stylers": [{ "color": "#17263c" }] }];

  return (
    <View style={styles.container}>
      <View style={styles.item} >
        <View style={styles.searchContent}>
          <TextInput
            onChangeText={(text) => { _handleSearchContent(text) }}
            editable={true}
            multiline={false}
            maxLength={200}
            placeholder="search..."
            autoCapitalize="none"
            value={searchContent}
          />
        </View>
        <View>
          <View style={styles.itemTitle}>
            <TouchableOpacity onPress={() => setModalVisible(true)}>
              {filterStatus ? 
                <Image style={styles.selectActiveTag} source={require('../assets/images/inactive.png')} /> :
                <Image style={styles.selectActiveTag} source={require('../assets/images/active.png')} />
              }
            </TouchableOpacity>
          </View>
        </View>
        <View>
          <View style={styles.itemTitle}>
            <TouchableOpacity onPress={() => _handleSearch()}>
              <Image style={styles.searchButton}
                source={require('../assets/images/search.png')} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
       <Modal animationType="fade" visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}>
        <KeyboardAvoidingView behavior={Platform.OS == "ios" ? "padding" : height} style={styles.container}>
          <View style={styles.modalView}>
            <View style={styles.logoContainerLogoutButton}>
                <TouchableOpacity onPress={() => { setModalVisible(false) }} style={styles.backButtonContainer} >
                  <Text style={styles.backButtonModal} >Back</Text>
                </TouchableOpacity>
            </View>
            <View style={styles.header}>
              <View style={styles.headerTextContainer}>
                <Text style={styles.headerText}> Filter </Text>
              </View>
            </View>
           <View style={styles.contentContainer}>
              <FlatList
                data={userTechnicalCatetory}
                keyExtractor={(item) => item.item}
                renderItem={renderItem}
              />
            </View>
            <View style={styles.modelButtonContainer}>
              <TouchableHighlight 
                style={styles.modalButton} onPress={() => _handleFilter()}>
                <Button style={styles.modalText} title="SAVE" />
              </TouchableHighlight>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
      <MapView
        style={styles.map}
        initialRegion={initialRegion}
        customMapStyle={mapStyle}
        mapType={mapTypes}
        showsUserLocation={true}
        onRegionChange={onRegionChange}
        onRegionChangeComplete={onRegionChange}
        // onRegionChange={region => setRegion({ region })}
        // onRegionChangeComplete={region => setRegion({ region })}
        zoomEnabled={true}
        showsMyLocationButton={false}
      >
        {metaDatas.length > 0 && metaDatas.map((metaData) => {
          if (metaData["latitude"] && metaData["longitude"]) {
            return <Marker
            draggable
            coordinate={{
              latitude: parseFloat(metaData["latitude"]),
              longitude: parseFloat(metaData["longitude"]),
            }}
            onDragEnd={(e) => _handleMarker(e, metaData)}
            image={colorButton[(metaData["technical_category"])]}
            onPress={() => _handleMarker(metaData)}
            onCalloutPress={() => _handleMarker(metaData)}
            key={metaData["id"]}
          >
            <MapView.Callout>
              <TouchableHighlight onPress={() => _handleMarker(metaData)}>
                <View>
                  <Text>Equipment: {metaData["equipment_name"]}</Text>
                  <Text>Technical Category: {metaData["technical_category"]}</Text>
                </View>
              </TouchableHighlight>
            </MapView.Callout>
          </Marker>}
          })
        }
      </MapView>
       <View style={styles.itemTag} >
        <View style={styles.marginLeft}>
          <View style={styles.itemTagTitle}>
            <Text>Equipment Name:</Text>
          </View>
        </View>

        <View style={styles.itemContent}>
          <TextInput
            editable={false}
            multiline={false}
            maxLength={200}
            value={tagID}
          />
        </View>
      </View>
      <View style={styles.itemTagType} >
        <View style={styles.marginLeft}>
          <View style={styles.itemTagTitle}>
            <Text>Technical Category:</Text>
          </View>
        </View>

        <View style={styles.itemContent}>
          <TextInput
            editable={false}
            multiline={false}
            maxLength={200}
            value={energyArt}
          />
        </View>
      </View>
      <View style={styles.buttonGroup} >
        <TouchableOpacity onPress={() => _goMetaData()}>
          <View style={styles.buttonGroupContainer}>
            <View style={styles.itemTitle}>
              <Image style={styles.buttonService}
                source={require('../assets/images/eqiup_data.png')} />
            </View>
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => _goActivityLog()}>
          <View style={styles.buttonGroupContainer}>
              <View style={styles.itemTitle}>
                <Image style={styles.buttonService}
                  source={require('../assets/images/new_active_log1.png')} />
              </View>
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('EquipmentList')}>
          <View style={styles.buttonGroupContainer}>
              <View style={styles.itemTitle}>
                <Image style={styles.buttonService_small}
                  source={require('../assets/images/equipment_list.png')} />
              </View>
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => _handleMapType()}>
          <View style={styles.buttonGroupContainer}>
            <View style={styles.itemTitle}>
              <Image style={styles.buttonService_small}
                  source={require('../assets/images/location_2.png')} />
            </View>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    height: 50,
    width: '105%',
    backgroundColor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: "row",
  },
  headerTextContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: "row",
  },
  headerText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000000',
  },
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'flex-end',
    backgroundColor: '#548235'
  },
  map: {
    position: 'absolute',
    top: 50,
    left: 10,
    right: 10,
    bottom: '40%',
    borderRadius: 20
  },
  logoutButton: {
    marginRight: 20,
    padding: 5,
    marginBottom: 0,
    width: 40,
    height: 40
  },
  backButton: {
    marginLeft: 20,
    padding: 10,
    paddingLeft: 20,
    paddingRight: 20,
    marginBottom: 0,
    backgroundColor: '#7b8d93',
    color: '#ffffff',
    borderRadius: 5,
    justifyContent: "center",
  },
  item: {
    position: 'absolute',
    flexDirection: 'row',
    borderBottomWidth: 5,
    borderBottomColor: '#548235',
    alignItems: 'center',
    justifyContent: "center",
    top: 10,
    width: '117%'
  },
  itemTag: {
    position: 'absolute',
    flexDirection: 'row',
    borderBottomWidth: 5,
    borderBottomColor: '#548235',
    alignItems: 'center',
    bottom: '30%',
    justifyContent: "center",
    width: '70%',
    borderRadius: 20
  },
  itemTagType: {
    position: 'absolute',
    flexDirection: 'row',
    borderBottomWidth: 5,
    borderBottomColor: '#548235',
    alignItems: 'center',
    bottom: '23%',
    justifyContent: "center",
    width: '70%'
  },
  buttonGroup: {
    position: 'absolute',
    flexDirection: 'row',
    borderBottomWidth: 5,
    borderBottomColor: '#548235',
    alignItems: 'center',
    bottom: '5%',
    justifyContent: "center",
    width: '60%'
  },
  marginLeft: {
    marginLeft: 5,
  },
  text: {
    fontSize: 15,

  },

  itemContent: {
    width: '80%',
    height: 35,
    backgroundColor: '#ffffff',
    justifyContent: "center",
    borderTopRightRadius: 10,
    borderBottomRightRadius: 10
  },

  searchContent: {
    width: '70%',
    height: 35,
    backgroundColor: '#ffffff',
    justifyContent: "center",
    paddingLeft: 10,
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10
  },
  searchButton: {
    width: 35,
    height: 35,
    borderTopRightRadius: 10,
    borderBottomRightRadius: 10
  },
  buttonSerial: {
    width: 65,
    height: 65,
  }, buttonService: {
    width: 75,
    height: 75,
  },
  buttonService_small: {
    width: 65,
    height: 65,
  },
  itemTagTitle: {
    borderWidth: 1,
    width: 165,
    height: 35,
    alignItems: "center",
    justifyContent: "center",
    borderColor: '#ffffff',
    backgroundColor: '#ffffff',
    paddingLeft: 35,
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10
  },
  buttonGroupContainer: {
    marginLeft: 5,
    borderRadius: 10,
    width: 80,
    height: 80,
    backgroundColor: '#FFFFFF',
    alignItems: "center",
    justifyContent: "center"
  },
  buttonGroupContainerActive: {
    marginLeft: 5,
    borderRadius: 10,
    width: 80,
    height: 80,
    backgroundColor: 'orange',
    alignItems: "center",
    justifyContent: "center"
  },
  textStyle: {
    fontSize: 15,
    fontWeight: "bold",
    letterSpacing: 0.1,
    color: '#fff',
    textAlign: 'center'
  },
  selectActiveTag: {
    width: 35,
    height: 35,
  },

  itemModal: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center'
  },
  itemTitleModal: {
    borderWidth: 5,
    padding: 10,
    width: 150,
    height: 50,
    borderColor: '#969696',
    backgroundColor: '#98a4a9',
    alignItems: "center",
    justifyContent: "center",
  },
  itemTitleText: {
    fontSize: 15,
    color: '#ffffff',
  },
  itemContentModal: {
    width: '60%',
    height: 50,
    maxHeight: 50,
    backgroundColor: '#c4d3db',
    justifyContent: "center",
    paddingLeft: 10,
  },
  modalButton: {
    width: 130,
    borderWidth: 2,
    marginTop: 20,
    borderRadius: 20,
    borderColor: '#ffffff',
    backgroundColor: '#ffffff',
    margin: 20
  },
   modelButtonContainer: {
    flexDirection: "row",
    justifyContent: "center"
  },
  contentContainer: {
    height: '60%',
    marginTop: 10
  },
  logoContainerLogoutButton: {
    position: "absolute",
    top: hp('4%'),
    width: '110%',
    borderBottomWidth: 1,
    borderColor: '#fff',
    padding: 5,
  },
  backButtonModal:  {
    padding: 10,
    marginBottom: 0,
    justifyContent: "center",
    borderRadius: 5,
    textAlign: "center",
    color: '#ffffff',
  },
  backButtonContainer: {
    width: '25%',
    borderRadius: 10,
    backgroundColor: '#7b8d93',
  },
  modalView: {
    flex: 1,
    backgroundColor: '#548235',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%'
  },
});

export default App;