import React, { Component, useState, useEffect, useLayoutEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  TextInput,
  Alert,
  ActivityIndicator,
  Button,
  FlatList,
  Modal,
  TouchableHighlight,
  KeyboardAvoidingView,
  Keyboard,
  ScrollView,
  Linking
} from 'react-native';
import NfcManager, { NfcTech, Ndef } from 'react-native-nfc-manager';
import AsyncStorage from "@react-native-community/async-storage";
import Geolocation from '@react-native-community/geolocation';
import CheckBox from 'react-native-check-box';
import SelectInput from 'react-native-select-input-ios';
import {
 heightPercentageToDP as hp,
 widthPercentageToDP as wp,
} from 'react-native-responsive-screen'
import email from 'react-native-email'
import { exp } from 'react-native-reanimated';


export default function Metadata({ route, navigation }) {
  const [metaData, setMetaData] = useState()
  const [modalVisible, setModalVisible] = useState(false)
  const [inputText, setInputText] = useState('')
  const [editedItem, setEditedItem] = useState(0)
  const [itemTitle, setItemTitle] = useState()
  const [rowID, setRowID] = useState()
  const [nfcTagID, setNfcTagID] = useState()
  const [nfcTAG, setNfcTAG] = useState()
  const [equipmentName, setEquipmentName] = useState('')
  const [currentLatitude, setCurrentLatitude] = useState('')
  const [currentLogitude, setCurrentLongitude] = useState('')
  const [serviceRepair, setServiceRepair] = useState('')
  const [dueTime, setDueTime] = useState('')
  const [comment, setComment] = useState('')
  const [latestService, setLatestService] = useState('')
  const [newService, setNewService] = useState('')
  const [userName, setUserName] = useState('')
  const { nfc_id } = route.params;
  const [userAutherity, setUserAutherity] = useState();
  const [selectedLatitude, setSelectedLatitude] = useState();
  const [selectedLongitude, setSelectedLongitude] = useState();

  const [contactsModalVisible, setContactsModalVisible] = useState(false);
  const [contactsData, setContactsData] = useState();
  const [test, setTest] = useState(false)
  const [intervalDate, setIntervalDate] = useState();
  const [contactsString, setContactsString] = useState('');

  useEffect(() => {
    setNfcTagID(nfc_id)
    getMetaData(nfc_id)
    getCurrentLocation()
    AsyncStorage.getItem('customerID').then(value => {
      setUserName(value)
    });
    AsyncStorage.getItem('userAutherity').then(value => {
      setUserAutherity(value)
    });

  }, [nfc_id]);

  getMetaData = (tag_id) => {
    let api_url = 'http://23e64e346a8d.ngrok.io/editMetaMainData/' + tag_id;
    return fetch(api_url)
      .then((response) => response.json())
      .then((responseJson) => {
        setRowID(responseJson.id)
        setEquipmentName(responseJson.equipment_name)
        getLatestService(responseJson.equipment_name)
        setSelectedLatitude(responseJson.latitude)
        setSelectedLongitude(responseJson.longitude)
        setIntervalDate(responseJson.service_interval)
        let metaData = [
          { item: 'equipment_name', text: 'Equipment Name:', value: responseJson.equipment_name },
          { item: 'expected_service', text: 'Expected Service:', value: ((responseJson.expected_service).replace('T', ' ')).replace('Z', '') },
          { item: 'technical_category', text: 'Technical Type:', value: responseJson.technical_category },
          { item: 'nfc_tag', text: 'NFC Tag:', value: responseJson.nfc_tag },
          { item: 'service_interval', text: 'Service Interval:', value: (responseJson.service_interval + ' [Month]') },
          { item: 'legit', text: 'Legit:', value: responseJson.legit },
          { item: 'contacts', text: 'Contacts:', value: responseJson.contacts },
          { item: 'longitude', text: 'Longitude:', value: responseJson.longitude },
          { item: 'latitude', text: 'Latitude:', value: responseJson.latitude },
        ]
        setMetaData(metaData)
        setNfcTAG(responseJson.nfc_tag)
        let contacts = []
        JSON.parse(responseJson.contacts).map((contact) => 
          contacts.push({item: contact["label"], text: contact["label"], value: contact["label"], checkStatus: false})
        )
        setContactsData(contacts)
        let tempString = ""
        let contactsConvert = (JSON.parse(responseJson.contacts))
        for (var i = 0; i < contactsConvert.length; i++) {
          if (i < 2) {
            tempString = tempString.concat(`${contactsConvert[i]["user_name"]}, `)
          } else {
            tempString = tempString.concat(`and ${contactsConvert.length - 2} more`)
            break;
          }
        }
        setContactsString(tempString);
      })
  }

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <View>
          <TouchableOpacity onPress={() => navigation.navigate('Home')}>
            <Image style={styles.logoutButton}
              source={require('../assets/images/logo.png')} />
          </TouchableOpacity>
        </View>
      ),
      headerLeft: () => (
        <View>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Text style={styles.backButton}
              source={require('../assets/images/logo.png')}>Back</Text>
          </TouchableOpacity>
        </View>
      ),
    });
  }, [navigation]);

  _handleActivity = () => {
    Alert.alert(
      'Are you sure to save?',
      '',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('OK Pressed'),
          style: 'cancel',
        },
        { text: 'OK', onPress: () => _saveActivity() },
      ],
      { cancelable: false },
    );
  }

  _addActivity = () => {
    _handleNewDate()
    let alertData = "Please select item"
    Alert.alert(
      alertData,
      'Are you sure?',
      [
        {
          text: 'Service',
          onPress: () => {setServiceRepair("Service"); setModalVisible(true);},
          style: 'cancel',
        },
        { text: 'Repair', onPress: () => { setModalVisible(true); setServiceRepair("Repair") }},
      ],
      { cancelable: false },
    );
   
  }

  _handleValidation = (text) => {
    let newText = '';
    let numbers = '0123456789';

    for (var i=0; i < text.length; i++) {
      if(numbers.indexOf(text[i]) > -1) {
        newText = newText + text[i];
      } else {
        alert("Please enter numbers only");
      }
    }
    setDueTime(newText);
  }

  getLatestService = (equipmentName) => {
    let api_url = 'http://23e64e346a8d.ngrok.io/getMetaActivityService/' + equipmentName;
    return fetch(api_url)
      .then((response) => response.json())
      .then((responseJson) => {
        let convertJson = JSON.parse(responseJson)
        if (convertJson.length > 0) {
          setLatestService(convertJson[(convertJson.length) - 1]["fields"]["date"])
        } else {
          setLatestService(newService)
        }
      })
  }

  _handleNewDate = () => {
    let currentDate = getCurrentDate()
    setNewService(currentDate)
  }

  getCurrentDate = (interval=0) => {
    let date = new Date().getDate(); //Current Date
    let month = new Date().getMonth() + 1 + parseInt(interval); //Current Month
    let year = new Date().getFullYear(); //Current Year
    let hours = new Date().getHours(); //Current Hours
    if (hours < 10) {
      hours = "0" + hours;
    }
    let min = new Date().getMinutes(); //Current Minutes
    if (min < 10) {
      min = "0" + min;
    }
    let sec = new Date().getSeconds();
    if (sec < 10) {
      sec = "0" + sec;
    }
    let currentDate = year + '-' + month + '-' + date + ' ' + hours + ':' + min + ':' + sec
    return currentDate;
  }


  _saveActivity = () => {
    let formData = new FormData();
    let dt = new Date()
    let currentDateTime = getCurrentDate()
    let expectedDateTime = getCurrentDate(intervalDate)
    let latest_service = (((new Date(dt.setMonth(dt.getMonth()))).toISOString()).split('.'))[0]
    let tempDateTime = (new Date(dt.setMonth(dt.getMonth() + parseInt(intervalDate))))
    tempDateTime.setHours( tempDateTime.getHours() + 1 );
    let expected_service = ((tempDateTime.toISOString()).split('.'))[0]
    formData.append("equipment_name", equipmentName)
    formData.append("service_repair", serviceRepair)
    formData.append("due_time", dueTime)
    formData.append("comment", comment)
    formData.append("nfc_id", nfc_id)
    formData.append("expected_date", expected_service)
    formData.append("latest_service", latest_service)
    formData.append("serviced_by", userName)


    fetch('http://23e64e346a8d.ngrok.io/addMataArchive/', {
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      body: formData
    })                    
      .then((response) => response.json())
      .then(response => {
        if (response.success == "true") {
          setModalVisible(false)
          setComment('');
          setDueTime('');
          getMetaData(nfc_id)
        } else {
          alert("save error")
        }
      }).catch(err => {
        console.log(err)
      })
  }

  getCurrentLocation = () => {
    Geolocation.getCurrentPosition(
      //Will give you the current location
      (position) => {
        let longitude = JSON.stringify(position.coords.longitude);
        let latitude = JSON.stringify(position.coords.latitude);
        setCurrentLatitude(latitude)
        setCurrentLongitude(longitude)
        AsyncStorage.setItem('currentLongitude', longitude);
        AsyncStorage.setItem('currentLatitude', latitude);

      },
      (error) => alert(error.message),
      {
        enableHighAccuracy: true, timeout: 15000, maximumAge: 10000
      }
    )
  }


  _getLocation = () => {
    if (userAutherity == 'Admin') {
    let alertData = "Get Current Location"
      Alert.alert(
        'Are you sure?',
        alertData,
        [
          {
            text: 'Cancel',
            onPress: () => console.log('OK Pressed'),
            style: 'cancel',
          },
          { text: 'OK', onPress: () => _upDateLocation() },
        ],
        { cancelable: false },
      );
    } else {
      alert("Only Available if user had User Authority  'Admin'")
    }
  }

  _upDateLocation = () => {
    let formData = new FormData();
    formData.append("id", nfc_id);
    formData.append("longitude", currentLogitude);
    formData.append("latitude", currentLatitude);
    fetch('http://23e64e346a8d.ngrok.io/updateMetaMainDataLocation/', {
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      body: formData
    })                    
    .then((response) => response.json())
    .then(response => {
      if (response.success == "true") {
        getMetaData(nfc_id)
      } else {
        alert("save error")
      }
    }).catch(err => {
      console.log(err)
    })
  }

  _goMap = () => {
    navigation.navigate('Location', {equipment_name: equipmentName, longitude: selectedLongitude, latitude: selectedLatitude})
  }

  _handleEmail = (email) => {
    let link = "mailto:" + email
    Linking.openURL(link)
  }




  const sendEmail = () => {
    let toAddress = []
    contactsData.map((data, key) => {
      if(data.checkStatus) {
        toAddress.push(data.item)
      }
    })
    var to = toAddress
    email(to, {
        // Optional additional arguments
        cc: toAddress, // string or array of email addresses
        bcc: 'mee@mee.com', // string or array of email addresses
        subject: 'Please insert Subject',
        body: 'Please insert Content.'
    }).catch(console.error)
  }

  const _handleCheckBox = (index) => {
    contactsData[index].checkStatus = !contactsData[index].checkStatus
    setContactsData(contactsData)
    setTest(!test)
  }

  renderItem = ({ item, index }) => (
    <TouchableHighlight onPress={() => { _handleCheckBox(index)}}
      underlayColor={'#f1f1f1'}>
      <View style={styles.item} >
        <View style={styles.marginLeft}>
         <TouchableHighlight onPress={() => _handleCheckBox(index)}>
            <View style={styles.itemTitleModal} >
              <CheckBox
                  onClick={() => {
                    _handleCheckBox(index);
                  }}
                  isChecked={contactsData[index].checkStatus}
              />
            </View>
        </TouchableHighlight>
        </View>
        <View style={styles.itemContent}>
            <Text style={styles.text}>{item.value}</Text>
        </View>
      </View>
    </TouchableHighlight>
  )

  return (
    <View style={styles.container}>
      <View style={styles.contentContainer}>
        {metaData && metaData.map((item, key) => {
          return (
            <View style={styles.item} key={key}>
              <View style={styles.itemTitleContainer}>
                <View style={styles.itemTitle}>
                  <Text style={styles.itemTitleText}>{item.text}</Text>
                </View>
              </View>
              <View style={styles.itemContent}>
                { item.item != 'contacts' ?  
                  <Text style={styles.text}>{item.value} </Text> :
                    <TouchableOpacity onPress={() => setContactsModalVisible(true)}>
                      <View style={styles.scrollText}>
                        <Text style={styles.text}>{contactsString}</Text>
                      </View>
                  </TouchableOpacity>
                }
              </View>
            </View>
          )
        })}
      </View>
      <Modal animationType="fade" visible={contactsModalVisible}
        onRequestClose={() => setContactsModalVisible(false)}>
        <KeyboardAvoidingView behavior={Platform.OS == "ios" ? "padding" : height} style={styles.container}>
          <View style={styles.modalView}>
            <View style={styles.logoContainerLogoutButton}>
                <TouchableOpacity onPress={() => { setContactsModalVisible(false) }} style={styles.backButtonContainer} >
                  <Text style={styles.backButtonModal} >Back</Text>
                </TouchableOpacity>
            </View>
            <View style={styles.header}>
              <View style={styles.headerTextContainer}>
                <Text style={styles.headerText}> Contacts </Text>
              </View>
            </View>
            <View style={styles.contentContainerContact}>
              <FlatList
                data={contactsData}
                keyExtractor={(item, key) => key}
                renderItem={renderItem}
              />
            </View>
            <View style={styles.modelButtonContainer}>
              <TouchableHighlight 
                style={styles.modalButton}>
                <Button style={styles.modalText} title="CONTACT" onPress={sendEmail} />
              </TouchableHighlight>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
      <Modal animationType="fade" visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}>
        <KeyboardAvoidingView behavior={Platform.OS == "ios" ? "padding" : height} style={styles.container}>
          <View style={styles.modalView}>
            <View style={styles.logoContainerLogoutButton}>
                <TouchableOpacity onPress={() => { setModalVisible(false) }} style={styles.backButtonContainer} >
                  <Text style={styles.backButtonModal} >Back</Text>
                </TouchableOpacity>
            </View>
            <View style={styles.item} >
              <View style={styles.itemTitleContainer}>
                <View style={styles.itemTitle}>
                  <Text style={styles.itemTitleText}>Latest Service:</Text>
                </View>
              </View>
              <View style={styles.itemContent}>
                <TextInput
                  defaultValue={(latestService.replace('T', ' ')).replace('Z', '')}
                  multiline={true}
                  editable={false}
                  maxLength={200}
                />
              </View>
            </View>
            {
              serviceRepair == "Service" ?
              <View style={styles.item} >
                <View style={styles.itemTitleContainer}>
                  <View style={styles.itemTitle}>
                    <Text style={styles.itemTitleText}>New Service:</Text>
                  </View>
                </View>
                <View style={styles.itemContent}>
                  <TextInput
                    defaultValue={newService}
                    multiline={true}
                    editable={false}
                    maxLength={200}
                  />
                </View>
              </View> :
              <></>
            }
            <View style={styles.itemCliclable} >
              <View style={styles.itemContentPlaceholder}>
                <TextInput
                  onChangeText={(text) => { _handleValidation(text) }}
                  defaultValue={dueTime}
                  placeholder = "Time spent on activity... (Hours(s)):"
                  placeholderTextColor="#000f"
                  editable={true}
                  multiline={false}
                  maxLength={200}
                  keyboardType='numeric'
                  style={styles.textColor}
                />
              </View>
            </View>
            <View style={styles.itemCliclable} >
              <View style={styles.itemContentPlaceholder}>
                <TextInput
                  onChangeText={(text) => { setComment(text) }}
                  defaultValue={comment}
                  placeholder = "Note..."
                  placeholderTextColor="#000f"
                  editable={true}
                  multiline={true}
                  style={styles.textColor}
                  maxLength={200}
                />
              </View>
            </View>
            <View style={styles.modelButtonContainer}>
              <TouchableHighlight onPress={() => _handleActivity()}
                style={styles.modalButtonText}>
                <Text style={styles.modalText}> Save </Text>
              </TouchableHighlight>
              <TouchableHighlight onPress={() => setModalVisible(false)}
                style={styles.modalButtonText}>
                <Text style={styles.modalText}>Cancel</Text>
              </TouchableHighlight>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

     <View style={styles.buttonGroup} >
        <TouchableOpacity onPress={() => _getLocation()}>
          <View style={styles.buttonGroupContainer}>
          <View>
              <Image style={styles.buttonService_small}
                  source={require('../assets/images/getLocation.png')} />
            </View>
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('ActivityLog', { nfc_id: rowID, equipment_name: equipmentName })}>
          <View style={styles.buttonGroupContainer}>
            <View>
                <Image style={styles.buttonService_small}
                    source={require('../assets/images/new_active_log1.png')} />
              </View>
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => _addActivity()}>
          <View style={styles.buttonGroupContainer}>
            <View>
                  <Image style={styles.buttonService_small}
                  source={require('../assets/images/new_active_log.png')} />
                </View>
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => _goMap()}>
          <View style={styles.buttonGroupContainer}>
              <View>
                  <Image style={styles.buttonService}
                  source={require('../assets/images/equip_location.png')} />
                </View>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );

}


const styles = StyleSheet.create({
  header: {
    height: 50,
    width: '100%',
    backgroundColor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#548235',
    borderRadius: 5,
    flexDirection: "row",
    marginTop: -50
  },
  headerTextContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: "row",
  },
  headerText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000000',
  },
  buttonService: {
    width: 75,
    height: 75,
  },
  buttonService_small: {
    width: 65,
    height: 65,
  },
  headerTextXY: {
    fontSize: 38,
    color: '#000000',
  },
  container: {
    backgroundColor: '#548235',
    padding: 5,
    height: '100%'
  },
  contentContainer: {
    marginTop: 20,
    height: '75%',
  },
  contentContainerContact: {
    marginTop: 10,
    height: '55%',
  },
  item: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#548235',
    alignItems: 'center',
  },
  itemCliclable: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    backgroundColor: '#ccc',
    alignItems: 'center',
  },
  menu: {
    width: 20,
    height: 2,
    backgroundColor: '#111',
    margin: 2,
    borderRadius: 3,
  },
  text: {
    fontSize: 15,

  },
  scrollText: {
    flexDirection: 'row',
    borderColor: '#548235',
    padding: 12,
    width: '98%',
    backgroundColor: '#ccc'
    
  },
  modalText: {
    fontSize: 18,
    fontWeight: "bold"

  },
  itemContent: {
    width: '60%',
    height: 50,
    maxHeight: 50,
    backgroundColor: '#c4d3db',
    justifyContent: "center",
    paddingLeft: 10,
  },
  itemContentPlaceholder: {
    width: '100%',
    height: 50,
    maxHeight: 50,
    backgroundColor: '#ccc',
    justifyContent: "center",
    paddingLeft: 30,
  },
  itemTitleText: {
    fontSize: 15,
    color: '#000',
  },

  textInput: {
    width: '90%',
    marginLeft: 10,
    marginRight: 10,
    marginBottom: 30,
    borderColor: 'gray',
    borderBottomWidth: 2,
    fontSize: 16,
  },
  modalView: {
    flex: 1,
    backgroundColor: '#548235',
    alignItems: 'center',
    justifyContent: 'center',
  },
  touchableHighlight: {
    backgroundColor: 'white',
    marginVertical: 10,
    alignSelf: 'stretch',
    alignItems: 'center',
  },
  logoutButton: {
    marginRight: 20,
    padding: 5,
    marginBottom: 0,
    width: 40,
    height: 40
  },
  backButton: {
    marginLeft: 20,
    padding: 10,
    marginBottom: 0,
    paddingLeft: 20,
    paddingRight: 20,
    backgroundColor: '#7b8d93',
    color: '#ffffff',
    borderRadius: 10,
    justifyContent: "center",
  },
  itemTitle: {
    padding: 10,
    height: 50,
    backgroundColor: '#c4d3db',
    alignItems: "center",
    justifyContent: "center",

  },
  itemTitleContainer: {
    width: '40%'
  },
  logoContainer: {
    marginBottom: '10%',
    justifyContent: 'flex-end',
    alignItems: "center",
  },
  modalButtonText: {
    borderWidth: 2,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    marginTop: 20,
    borderRadius: 15,
    borderColor: '#ffffff',
    backgroundColor: '#ffffff',
    margin: 20,
    width: 100,
    alignItems: "center"
  },
  modelButtonContainer: {
    flexDirection: "row",
  },
  bottomContaner: {
    flexDirection: "row",
    alignItems: "baseline",
    justifyContent: "space-between",
    marginTop: 5

  },
  getLocation: {
    width: 40,
    height: 40,
    marginLeft: '10%',
    borderWidth: 1,
    borderColor: '#ffffff',
    borderRadius: 10,
    backgroundColor: '#ffffff'
  },
  bottomRightContainer: {
    flexDirection: "row"
  },
  selectInput: {
    flexDirection: 'row',
    padding: 8,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  buttonGroup: {
    position: 'absolute',
    flexDirection: 'row',
    borderBottomWidth: 5,
    borderBottomColor: '#548235',
    alignItems: 'center',
    bottom: '5%',
    justifyContent: "center",
    width: '100%'
  },
  buttonGroupContainer: {
      marginLeft: 5,
      borderRadius: 10,
      width: 85,
      height: 80,
      backgroundColor: '#FFFFFF',
      alignItems: "center",
      justifyContent: "center",
      padding: 3
  },
  textStyle: {
    fontSize: 14,
    fontWeight: "bold",
    letterSpacing: 0.1,
    color: '#fff',
    textAlign: 'center'
  },
   logoContainerLogoutButton: {
    position: "absolute",
    top: hp('4%'),
    width: '100%',
    borderBottomWidth: 1,
    borderColor: '#fff',
    padding: 5,
  },
  backButtonContainer: {
    width: '25%',
    borderRadius: 10,
    backgroundColor: '#7b8d93',
  },
  backButtonModal:  {
    padding: 10,
    marginBottom: 0,
    justifyContent: "center",
    borderRadius: 5,
    textAlign: "center",
    color: '#ffffff'
  },
  itemTitleModal: {
    borderWidth: 5,
    padding: 10,
    width: 150,
    height: 50,
    borderColor: '#969696',
    backgroundColor: '#98a4a9',
    alignItems: "center",
    justifyContent: "center",
  },
  modelButtonContainer: {
    flexDirection: "row",
    justifyContent: "center"
  },
  modalButton: {
    width: 130,
    borderWidth: 2,
    marginTop: 20,
    borderRadius: 20,
    borderColor: '#ffffff',
    backgroundColor: '#ffffff',
    margin: 20
  },
  textColor: {
    color: '#000000'
  }
})

