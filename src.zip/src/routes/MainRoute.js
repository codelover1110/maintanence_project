import * as React from 'react';
import { Button, View, Text, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator, HeaderTitle, HeaderBackButton } from '@react-navigation/stack';
import Login from '../pages/Login';
import PasswordReset from '../pages/PasswordReset';
import ActivityLog from '../pages/ActivityLog';

import Nfctag from '../pages/Nfctag';
import Home from '../pages/Home';
import Metadata from '../pages/Metadata';
import Location from '../pages/Location';
import EquipmentList from '../pages/EquipmentList';

const Stack = createStackNavigator();

function App() {
  const handleLogout = (navigation) => {
    navigation.Screen('BACK')

  }
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen
          name="Login"
          component={Login}
          options={{
            headerShown: false
          }}
        />
        <Stack.Screen
          name="PasswordReset"
          component={PasswordReset}
          options={{
            headerShown: false
          }}
        />
        <Stack.Screen
          name="ActivityLog"
          component={ActivityLog}
          options={{
            headerTitle: '',
            headerStyle: {
              backgroundColor: '#548235',
              // shadowColor: 'transparent'
            },
            headerLeft: null
          }}
        />
        <Stack.Screen
          name="Nfctag"
          component={Nfctag}
          options={{
            headerShown: false
          }}
        />
        <Stack.Screen
          name="Home"
          component={Home}

          options={{
            headerShown: false
          }}
        />
        <Stack.Screen
          name="Metadata"
          component={Metadata}
          options={{
            headerTitle: '',
            headerStyle: {
              backgroundColor: '#548235',
              // shadowColor: 'transparent'
            },
            headerLeft: null
          }}
        />
        <Stack.Screen
          name="Location"
          component={Location}
          options={{
            headerTitle: '',
            headerStyle: {
              backgroundColor: '#548235',
            },
            headerLeft: null
          }}
        />
        <Stack.Screen
          name="EquipmentList"
          component={EquipmentList}
          options={{
            headerTitle: '',
            headerStyle: {
              backgroundColor: '#548235',
            },
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
